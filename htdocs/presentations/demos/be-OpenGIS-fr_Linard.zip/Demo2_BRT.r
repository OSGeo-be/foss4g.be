# Loads required libraries
library(raster) 
library(rgdal)
library(maptools)
library(dismo)
library(classInt)
library(RColorBrewer)

# Sets the general path
#############################################################
setwd("C:/Users/Labo/Desktop/beOpenGIS/")

# Loads data
#############################################################
myD = read.csv("Data/H5N1_outbreaks.csv")
str(myD)

# Loads China provinces & map positives
#############################################################
myProvShape = readShapePoly("Data/China_prov")
# Plot China maps
plot(myProvShape, axes = T)
# Add outbreak locations
points(myD$XCOORD, myD$YCOORD, pch = 15, cex = 0.7, col=c("blue","red")[myD$IsPresent+1])


# Loads predictors and masks
#############################################################
# loads the file list
myVarList = list("ChDnLg",
                 "DuDnLg",
                 "AccessLg",
                 "Dem",
                 "WaterProp",
                 "HpopDnLg")

# Creates a raster brick with all covariates
covs <- brick(lapply(paste('Data/',
                           myVarList,'.asc',
                           sep = ''),
                     raster))

# Plot the predictors
plot(covs)

# Creates a mask layer
myMask = raster("Data/Dem.asc") > 0
plot(myMask)

# Apply the masking
covs = mask(covs, myMask)
plot(covs)

# Extract all predictors from raster stack
############################################################# 
myD = cbind(myD,extract(covs,myD[,1:2]))
str(myD)
# removes lines with no data
myFD = na.omit(myD)

#############################################################
# Creates the BRT model
#############################################################
# sets the dependent
myPosDep = match("IsPresent", names(myD))

# Sets the predictors
myPosPred = match(unlist(myVarList), names(myD))

# Run the BRT
myBRT = gbm.step(data=myD, gbm.x = myPosPred, gbm.y = myPosDep,
                 family = "bernoulli",tree.complexity = 4, learning.rate = 0.005, 
                 bag.fraction = 0.75, n.folds = 4, n.trees = 25, step.size = 50, 
                 plot.main = FALSE)

# PLots the summary of the BRT
summary(myBRT)  

# Plots the effects of the BRT
gbm.plot(myBRT)

# Create the output raster
myRasterDF = as.data.frame(getValues(covs))  
myPredV = predict.gbm(myBRT, myRasterDF,n.trees=myBRT$gbm.call$best.trees, type="response")
myPredR = setValues(myMask, myPredV)*myMask


#Create a map of the output
ncols = 9
myValVec = na.omit(sampleRegular(myPredR, 10000))

brks.km = classIntervals(myValVec, n=ncols,style="kmeans")       # kmeans
pal = brewer.pal(ncols,"BuPu")

plot(myPredR, breaks = brks.km$brks, col = pal, main = "Single BRT Model")
plot(myProvShape, add = T)












