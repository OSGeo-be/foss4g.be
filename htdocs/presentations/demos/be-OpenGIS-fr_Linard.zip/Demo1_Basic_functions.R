# Loads libraries
library(raster)
library(rgdal)

# Set working directory
setwd("C:/Users/Labo/Desktop/beOpenGIS/")

#Overview of the functions in the package
help(package="raster")


#######################################################
## Create a raster
#######################################################

#The main function to read raster data into R is called "raster"
?raster

#Let's make a raster!
r1 <- raster()
r1

n <- ncell(r1) #n = number of cells in raster r1
vals <- runif(n) # creates a vector with n values randomly selected between 0 and 1
values(r1) <- vals # add values to raster
plot(r1) #plot raster


#######################################################
## Crop and reproject a raster
#######################################################

# Loads the raster
myR = raster("Data/Dem.asc")
# plot the raster
plot(myR)
# Sets the raster projection system
myInProj = CRS("+proj=longlat +datum=WGS84")
projection(myR) = myInProj
# Sets the region to be extracted
xmin =  100
xmax = 120
ymin = 20
ymax = 35
myExtent = extent(xmin,xmax,ymin,ymax)
# Crop to the extent
myRC = crop(myR, myExtent)
plot(myRC)
# Sets the output projection (here we used a projection suitable for China)
myOutProj = CRS("+proj=eqdc +lat_0=30 +lon_0=95 +lat_1=15 +lat_2=65 +x_0=0 +y_0=0 +ellps=WGS84 +datum=WGS84 +units=m +no_defs")
# Reproject the raster
myRCT = projectRaster(myRC,res = 10000, crs = myOutProj, method="bilinear")
plot(myRCT)
# Option to save the raster
writeRaster(myRCT, "dem_projected.asc")


#######################################################
# Plot a grid with a custom legend
#######################################################
# Loads libraries
library(classInt)
library(RColorBrewer)

# plot the raster with the default legend
plot(myR) 
# Sets the number of classes
ncols = 9
# Sample the grid to find colour intervals
myValVec = na.omit(sampleRegular(myR, 10000))
# Identify the breaks (Other styles include "sd", "equal", "pretty", 
# "quantile", "kmeans", "hclust", "bclust", "fisher", or "jenks" 
brks.km = classIntervals(myValVec, n=ncols,style="quantile")     
# Sets the colour palette
# Sequential: Blues BuGn BuPu GnBu Greens Greys Oranges OrRd PuBu PuBuGn PuRd Purples RdPu Reds YlGn YlGnBu YlOrBr YlOrRd 
# Diverging: BrBG PiYG PRGn PuOr RdBu RdGy RdYlBu RdYlGn Spectral 
pal = brewer.pal(ncols,"YlOrRd")
plot(myR, breaks = brks.km$brks, col = pal, interpolate = F)

