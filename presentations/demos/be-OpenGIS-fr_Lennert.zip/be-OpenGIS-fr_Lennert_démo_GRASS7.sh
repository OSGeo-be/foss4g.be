echo "Source des données: European Climate Assessment and  Dataset  (ECAD)"
g.list -p rast
r.info temperature.mean.21372
t.create type=strds output=temperature_mean_2005_2010_daily temporal=absolute title="European mean temperature 2005-2010" description="Daily mean temperature in Europe between 2005 and 2010" --o
t.info temperature_mean_2005_2010_daily
g.list rast pat="temperature*" output=temp_maps.txt --o
head temp_maps.txt
t.register -i type=rast input=temperature_mean_2005_2010_daily file=temp_maps.txt start=2005-01-01 increment="1 day" --o
r.info temperature.mean.21372
t.info temperature_mean_2005_2010_daily
t.rast.aggregate input=temperature_mean_2005_2010_daily method=average output=temperature_mean_2005_2010_yearly  base=temp_mean_yearly granularity="1 year" --o
t.rast.aggregate input=temperature_mean_2005_2010_daily output=temperature_mean_2007_2009_seasonal base=temp_mean_seasonal granularity="3 months" method=average where="start_time >= '2007-01-01' AND start_time < '2010-01-01'"
t.rast.list temperature_mean_2007_2009_seasonal
t.rast.extract input=temperature_mean_2007_2009_seasonal where="strftime('%m', start_time)='07'" output=temperature_mean_2007_2009_summer
t.rast.list temperature_mean_2007_2009_summer
t.rast.extract input=temperature_mean_2005_2010_daily where="start_time>'2008-05-31' AND start_time<'2008-10-01'" output=temperature_mean_summer2008_daily
t.rast.list temperature_mean_summer2008_daily
g.gui.timeline &
t.rast.colors temperature_mean_2005_2010_yearly col=byr
t.rast.colors temperature_mean_summer2008_daily col=byr
t.rast.import rainfall_summer2008_daily output=rainfall_summer2008_daily base=rainfall extrdir=/tmp title="Rainfall 2008" description="Daily rainfall in Europe during the summer 2008"
t.info rainfall_summer2008_daily
g.gui.animation &
t.rast.series temperature_mean_summer2008_daily@eobs method=maximum output=temperature_mean_max_2008 where="start_time>='2008-01-01' AND start_time<'2008-10-01'"
r.colors temperature_mean_max_2008 col=byr
echo "Bon amusement avec les outils spatio-temporels de GRASS 7 !"
